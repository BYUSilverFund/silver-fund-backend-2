import pandas as pd


def transform(df: pd.DataFrame, fund: str, query: str) -> pd.DataFrame:
    xf_df = df[df['ClientAccountID'] != 'ClientAccountID'].copy()  # This transformation happens for all dataframes
    xf_df['fund'] = fund

    match query:

        case 'nav':
            xf_df = transform_nav(xf_df, fund)

        case 'delta_nav':
            xf_df = transform_delta_nav(xf_df, fund)

        case 'positions':
            xf_df = transform_positions(xf_df)

        case 'dividends':
            xf_df = transform_dividends(xf_df, fund)

        case 'trades':
            xf_df = transform_trades(xf_df)

        case _:
            raise "Bad query key name"

    return xf_df


def transform_nav(df, fund):
    xf_df = df
    xf_df['date'] = pd.to_datetime(xf_df['ReportDate'], format='%Y%m%d')

    if fund == 'quant':
        xf_df = xf_df.drop(columns=['IncentiveCouponAccruals','IncentiveCouponAccrualsShort','IncentiveCouponAccrualsLong'])

    return xf_df


def transform_delta_nav(df, fund):
    xf_df = df
    xf_df['date'] = pd.to_datetime(xf_df['FromDate'], format='%Y%m%d')

    if fund == 'quant':
        xf_df = xf_df.drop(columns=['ChangeInIncentiveCouponAccruals'])

    return xf_df


def transform_positions(df):
    xf_df = df
    xf_df['date'] = pd.to_datetime(xf_df['ReportDate'], format='%Y%m%d')
    return xf_df


def transform_dividends(df, fund):
    xf_df = df
    xf_df['date'] = pd.to_datetime(xf_df['ExDate'], format='%Y%m%d')

    if fund == 'quant':
        xf_df = xf_df.drop(columns=['ReportDate'])

    return xf_df


def transform_trades(df):
    xf_df = df
    xf_df['date'] = pd.to_datetime(xf_df['ReportDate'], format='%Y%m%d')
    return xf_df


def transform_rf(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()

    df.loc[:, 'yield'] = df['yield'] * .01

    df['yield'] = df['yield'].fillna(df['yield'].shift(1))

    df['yield_lag'] = df['yield'].shift(1)

    df['P0'] = 100 / (1 + df['yield_lag'] * 30 / 360)
    df['P1'] = 100 / (1 + df['yield'] * 29 / 360)

    df['return'] = df['P1'] / df['P0'] - 1
    df['yield'] = df['yield'] / 360

    df = df[['date', 'yield', 'return']]

    return df


def transform_bmk(df: pd.DataFrame) -> pd.DataFrame:
    xf_df = df[df['ClientAccountID'] != 'ClientAccountID'].copy()
    xf_df['date'] = pd.to_datetime(xf_df['ReportDate'], format='%Y%m%d')
    xf_df['MarkPrice'] = pd.to_numeric(xf_df['MarkPrice'])

    xf_df = xf_df[xf_df['Symbol'] == 'IWV']

    xf_df['ending_value'] = xf_df['MarkPrice']

    xf_df = xf_df[['date', 'ending_value']]

    return xf_df
